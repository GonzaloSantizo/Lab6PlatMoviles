package com.durini.fragments

import androidx.fragment.app.Fragment

class HomeFragment : Fragment(R.layout.fragment_home)