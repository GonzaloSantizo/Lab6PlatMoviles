package com.durini.fragments

import androidx.fragment.app.Fragment

class YourLibraryFragment : Fragment(R.layout.fragment_library)